import { defineConfig } from "oxlint"

export default defineConfig({
	options: {
		typeAware: true,
		typeCheck: true,
		maxWarnings: 10,
	},
	rules: {
		"no-console": "warn",
		"no-alert": "error",
		"oxc/approx-constant": "warn",
		"no-plusplus": "off",
		"eslint/prefer-const": ["error", { destructuring: "any" }],
	},
})
