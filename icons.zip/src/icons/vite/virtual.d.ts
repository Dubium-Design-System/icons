declare module "virtual:@dubium/icons-registry" {
	export const iconRegistry: import("./icon/Icon.types.js").TIconRegistry
}
